# Words for Comfort & Strength

A quiet, installable reading page of comfort-and-strength Bible verses (English/German), with a random-verse draw, bookmarking, and full offline support once installed.

## Files

```
index.html      the whole app (markup, styles, and logic)
manifest.json   PWA manifest (name, icons, colors, display mode)
sw.js           service worker — caches the app shell for offline use
icons/          app icons at 32/180/192/512px (the glowing cross)
```

## Deploying on GitHub Pages

1. Push this folder to a GitHub repo (root, or a subfolder if you prefer, in which case update the `start_url`, `scope`, and icon/manifest paths in `index.html`/`manifest.json` accordingly).
2. In the repo settings, enable **Pages** → deploy from the branch/folder containing these files.
3. Visit the published URL. On Android/Chrome you'll get an "Install app" prompt; on iOS Safari, use Share → "Add to Home Screen."

Service workers require **HTTPS** (GitHub Pages provides this automatically) or `localhost` for local testing — they won't register over plain `http://` on a custom server.

## Local testing

Service workers won't register when opening `index.html` directly via `file://`. Serve it locally instead, e.g.:

```bash
python3 -m http.server 8000
```

then open `http://localhost:8000`.

## Notes

- All verse text, bookmarks, and your language/theme choice are stored in the browser's `localStorage` — nothing is sent to a server.
- The verse translations are King James Version (English) and Luther 1912 (German), both public domain.
- To bump the cached version after editing `index.html`, increment `CACHE_NAME` in `sw.js` (e.g. `comfort-strength-v2`) so returning visitors get the update instead of a stale cache.
